const express = require("express");
const mysql = require("mysql2");
const bodyParser = require("body-parser");

const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "tugas",
});

connection.connect((err) => {
  if (err) {
    console.error("Terjadi kesalahan pada MySql :", err.stack);
    return;
  }
  console.log("Koneksi MySql berhasil dengan id" + connection.threadId);
});

app.set("view engine", "ejs");

//routing (create,read,update,delete)\
//read
app.get("/", (req, res) => {
  const query = "SELECT*FROM user";
  connection.query(query, (err, results) => {
    res.render("index", { user: results });
  });
});

app.post("/add", (req, res) => {
  const { nama, email, phone } = req.body;
  const query = "INSERT INTO user (nama,email,phone) VALUES (?,?,?)";
  connection.query(query, [nama, email, phone], (err, results) => {
    if (err) throw err;
    res.redirect("/");
  });
});

//update
app.get("/edit/:id", (req, res) => {
  const query = "SELECT*FROM user WHERE id = ?";
  connection.query(query, [req.params.id], (err, results) => {
    if (err) throw err;
    res.render("edit", { user: results[0] });
  });
});

//edit
app.post("/update/:id", (req, res) => {
  const { nama, email, phone } = req.body;
  const query = "UPDATE user SET nama = ?, email = ?, phone = ? WHERE id = ?";
  connection.query(query, [nama, email, phone, req.params.id], (err, results) => {
    if (err) throw err;
    res.redirect("/");
  });
});

// delete
app.get("/delete/:id", (req, res) => {
  const query = "DELETE FROM user WHERE id = ?";
  connection.query(query, [req.params.id], (err, results) => {
    if (err) throw err;
    res.redirect("/");
  });
});

app.listen(3006, () => {
  console.log("server berjalan di port 3006, buka web melalui http://localhost:3006");
});
